<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-frontend',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'frontend\controllers',
    'modules' => [
        'gridview' =>  [
            'class' => '\kartik\grid\Module',
        ],
        'backup' => [
            'class' => 'spanjeta\modules\backup\Module',
        ],
    ],
    'components' => [
        'request' => [
            'class' => 'common\components\Request',
            'web'=> '/frontend/web',
            'csrfParam' => '_csrf-frontend',
        ],
        'user' => [
            'identityClass' => 'common\models\User',
            'enableAutoLogin' => true,
            'identityCookie' => ['name' => '_identity-frontend', 'httpOnly' => true],
        ],
        'session' => [
            // this is the name of the session cookie used for login on the frontend
            'name' => 'advanced-frontend',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                //site
                'login' => 'site/login',
                //'logout' => 'site/login',
                'signup' => 'site/signup',
                'home' => 'site/index',
                'user-profile' => 'site/user-profile',
                'list-of-classes' => 'site/list-of-classes',
                'activity-view' => 'site/activity-view',
                'employe-dashboard'=>'site/employe-dashboard',
                'employee-portfolio'=>'site/employee-portfolio',
                'students-view'=>'site/students-view',
                'students-list'=>'site/students-list',
                'view-classes'=>'site/view-classes',
                'view-datesheet'=>'site/view-datesheet',
                'std-profile'=>'site/std-profile',
                'std-fee'=>'site/std-fee',
                'std-fee-details'=>'site/std-fee-details',
                'std-exams'=>'site/std-exams',
                'std-exam-schedule'=>'site/std-exam-schedule',
                'std-exam-result'=>'site/std-exam-result',
                'children'=>'site/children',
                'premium-version'=>'site/premium-version',
                'fee-details'=>'site/fee-details',
                'dates'=>'site/dates',
                'std-attendance-report' => 'site/std-attendance-report',
                'view-atten-incharge'=>'site/view-atten-incharge',
                'datewise-class-atten-view' => 'site/datewise-class-atten-view',
                'datewise-std-atten-view' => 'site/datewise-std-atten-view',
                'daterangewise-class-atten-view' => 'site/daterangewise-class-atten-view',
                'daterangewise-std-atten-view' => 'site/daterangewise-std-atten-view',
                'monthly-class-atten-view' => 'site/monthly-class-atten-view',
                //-------------------------------------------
                // executive-portal route
                'executive-portal' => 'site/executive-portal',
                'income-expense' => 'site/income-expense',
                'balance-sheet' => 'site/balance-sheet',
                
                //-------------------------------------------
                //std-attendance
                'attendance' => 'std-attendance',
                'student-attendance' => 'std-attendance/attendance',
                'class-attendance' => 'std-attendance/view-class-attendance',
                'view-attendance' => 'std-attendance/view-attendance',
                'test-attendance' => 'std-attendance/test-attendance',
                'take-attendance' => 'std-attendance/take-attendance',
                'datewise-class-attendance' => 'std-attendance/datewise-class-attendance',
                'datewise-student-attendance' => 'std-attendance/datewise-student-attendance',
                'daterangewise-class-attendance' => 'std-attendance/daterangewise-class-attendance',
                'daterangewise-student-attendance' => 'std-attendance/daterangewise-student-attendance',
                'monthly-attendance-view' => 'std-attendance/monthly-attendance-view',
                //std-attendance-by-incharge
                'attendance-by-incharge'=>'std-atten-incharge/attendance-by-incharge',
                'mark-attendance' => 'std-atten-incharge/mark-attendance',
                //-------------------------------------------
                //marks-details
                'marks-sheet'=>'marks-details/marks-sheet',
                'view-marks-list'=>'marks-details/view-marks-list',
                //-------------------------------------------
                //emp-leave
                'emp-leave'=>'emp-leave/index',
                'fetch-days-count'=>'emp-leave/fetch-days-count',
                //-------------------------------------------
                //timeTable
                'time-table-view' => 'time-table-head/time-table-view',
                'class-time-table-view' => 'time-table-head/class-time-table-view',
                'class-time-table' => 'time-table-head/class-time-table',
            ],
        ],
        
    ],
    'params' => $params,
];
