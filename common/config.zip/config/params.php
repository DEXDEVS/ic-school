<?php
return [
    'adminEmail' => 'anasshafqat02@gmail.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
];
